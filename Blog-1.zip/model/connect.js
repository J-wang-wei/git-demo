//导入mongoose
const mongoose = require('mongoose');

mongoose.set('useCreateIndex', true) //加上这个消掉一个报错信息

//连接数据库
mongoose.connect(`mongodb://root:root@localhost:27017/blog?authSource=admin`, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log("数据库连接成功"))
    .catch(() => console.log("数据库连接失败"))

// mongodb://username:password@localhost:27017/database