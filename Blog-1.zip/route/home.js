const express = require('express');
const home = express.Router();

home.get('/', require('./home/home'));

home.get('/article', require('./home/article'));

home.post('/comment-add', require('./home/comment-add'))

module.exports = home;