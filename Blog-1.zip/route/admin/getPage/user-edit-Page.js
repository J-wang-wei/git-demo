const { User } = require("../../../model/user");

module.exports = async(req, res, next) => {

    let user = await User.findOne({ _id: req.query.id });

    if (user) {
        res.render('admin/user-edit', {
            msg: req.query.msg,
            link: "/admin/user-modify?id=" + req.query.id,
            button: "修改",
            user: user,
            currentLink: 'user'
        });
    } else {
        res.render('admin/user-edit', {
            msg: req.query.msg,
            link: "/admin/user-edit",
            button: "增加",
            currentLink: 'user'
        });
    }

}