const { Comment } = require('../../model/comment');
module.exports = async(req, res) => {
    const data = req.body;
    // res.send(comment);
    data["date"] = new Date();

    Comment.create(data);

    res.redirect('/home/article?id=' + data.aid);
}