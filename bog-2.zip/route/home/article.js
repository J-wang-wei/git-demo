const { Article } = require("../../model/article");
const { Comment } = require('../../model/comment')

module.exports = async(req, res, next) => {
    let article = await Article.findOne({ _id: req.query.id }).populate('author');
    // res.send(article);
    let comments = await Comment.find({ aid: req.query.id }).populate('uid');

    res.render('home/article', {
        article,
        comments
    })
}