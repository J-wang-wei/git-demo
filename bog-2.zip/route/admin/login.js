//导入User集合
const { User } = require("../../model/user");

module.exports = async(req, res) => {
    const { email, password } = req.body;
    if (email.trim().length === 0 || password.trim().length === 0) {
        res.status(400).send({ status: 400, msg: "邮箱或者密码为空" });
    }
    // 必须把它进行异步处理
    const user = await User.findOne({ email: email });

    // 邮箱不存在
    if (!user) {
        return res.status(400).send({ status: 400, msg: "该邮箱尚未被注册" });
    }

    // 用户存在
    const isEqual = await user.password;
    if (isEqual) {
        req.app.locals.userInfo = user;
        req.session.user = user;
        //管理员用户
        if (user.role === 'admin') {
            req.session.username = user.username;
            res.redirect('/admin/user');
        } else {
            //普通用户
            res.redirect('/home');
        }
    } else {
        res.status(400).send({ status: 400, msg: "密码错误" });
    }

}