const { Article } = require('../../model/article');
module.exports = async(req, res) => {
    let id = req.body.id;
    let i = await Article.findOneAndDelete({ _id: id });
    if (i) {
        console.log("删除文章成功");
    } else {
        console.log(i);
    }
    res.redirect('/admin/article');
}