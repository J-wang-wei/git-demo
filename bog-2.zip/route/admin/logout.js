module.exports = (req, res) => {
    req.session.destroy(function() {
        req.app.locals.userInfo = null;
        res.clearCookie('connect.sid');
        res.redirect('/admin/login');
    })
}