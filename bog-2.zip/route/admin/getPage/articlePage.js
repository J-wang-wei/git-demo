const { Article } = require("../../../model/article");
const pagination = require('mongoose-sex-page');
module.exports = async(req, res, next) => {
    let page = req.query.page;
    req.app.locals.currentLink = 'article';
    let size = 10;
    let articles = await pagination(Article).find({}).page(page).size(size).display(3).populate('author').exec();
    let count = await Article.count({});
    // res.send(articles);
    res.render('admin/article', {
        articles,
        count
    });
}